// /js/year.js
const y = document.getElementById('y');
if (y) y.textContent = new Date().getFullYear();
