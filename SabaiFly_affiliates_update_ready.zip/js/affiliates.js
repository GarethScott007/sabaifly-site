(() => {
  const ATTR = 'data-affiliate';
  const REL  = 'nofollow sponsored noopener';
  async function load() {
    try {
      const res = await fetch('/data/affiliates.json', {cache: 'no-store'});
      if (!res.ok) return;
      const map = await res.json();
      document.querySelectorAll(`a[${ATTR}]`).forEach(a => {
        const k = a.getAttribute(ATTR);
        const url = map[k];
        if (url) {
          a.setAttribute('href', url);
          const existingRel = (a.getAttribute('rel') || '').trim();
          const want = new Set(REL.split(/\s+/));
          const have = new Set(existingRel.split(/\s+/).filter(Boolean));
          const merged = new Set([...want, ...have]);
          a.setAttribute('rel', Array.from(merged).join(' '));
          a.setAttribute('target', '_blank');
        }
      });
    } catch (e) {}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', load);
  } else {
    load();
  }
})();
